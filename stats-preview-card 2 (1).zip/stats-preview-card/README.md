# Frontend Mentor - Stats preview card component

This is a solution to the [Stats preview card component challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/stats-preview-card-component-8JqbgoU62).

## Overview

### The challenge

Users should be able to:

- View the optimal layout depending on their device's screen size

### Built with

- Semantic HTML5 markup
- CSS Flexbox
- Mobile-first responsive design
- Google Fonts (Inter & Lexend Deca)

## Author

- Frontend Mentor beginner project
